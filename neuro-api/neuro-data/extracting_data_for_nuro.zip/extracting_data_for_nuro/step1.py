# step1.py - Fetch relevant URLs from Google
from googlesearch import search

# Define the search query dynamically
query = "mindfulness techniques that support effective organizational skill"
num_results = 50  # Number of search results to collect

# Perform the search and save URLs
urls = [url for url in search(query, num_results=num_results)]

# Save the URLs to a file
with open("neurosync_search_results.txt", "w") as file:
    for url in urls:
        file.write(url + "\n")

print(f"Saved {len(urls)} URLs to neurosync_search_results.txt")
