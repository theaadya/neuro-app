# step2.py - Scrape relevant content from collected URLs
import requests
from bs4 import BeautifulSoup

# Function to read URLs from the saved search results file
def read_urls_from_file(file_path):
    with open(file_path, 'r') as file:
        return [line.strip() for line in file if line.strip()]

# Function to extract text content from a webpage
def extract_text_from_url(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # Extract main content (prioritizing relevant sections)
        article = soup.find('article') or soup.find('div', {'class': 'content'}) or soup.find('body')
        if article:
            paragraphs = article.find_all('p')  # Extract all paragraphs
            content = "\n".join([p.get_text(strip=True) for p in paragraphs])
            return content
        return None
    except Exception as e:
        print(f"Failed to fetch content from {url}: {e}")
        return None

# Read URLs from file
urls = read_urls_from_file("neurosync_search_results.txt")
all_text_data = []

for url in urls:
    print(f"Extracting from: {url}")
    text = extract_text_from_url(url)
    if text:
        all_text_data.append(f"[URL]: {url}\n[CONTENT]: {text}\n-------------------------\n")

# Save extracted text to a structured .txt file
output_file = "personal_organization_database4.txt"
with open(output_file, "w", encoding="utf-8") as file:
    file.writelines(all_text_data)

print(f"Saved extracted text to {output_file}")
